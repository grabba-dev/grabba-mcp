# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['src']

package_data = \
{'': ['*']}

install_requires = \
['grabba>=0.0.7,<0.0.8',
 'mcp[cli]>=1.9.3,<2.0.0',
 'pydantic-settings>=2.9.1,<3.0.0']

entry_points = \
{'console_scripts': ['grabba-mcp = src.cli:run_cli']}

setup_kwargs = {
    'name': 'grabba-mcp',
    'version': '0.0.1',
    'description': '',
    'long_description': '# mcp\n\n## About\n\nProject description here.\n\n[API Documentation](docs/source/api.md)\n\n## [Change log](CHANGELOG.md)\n',
    'author': 'Bolu Agbana',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10',
}


setup(**setup_kwargs)
